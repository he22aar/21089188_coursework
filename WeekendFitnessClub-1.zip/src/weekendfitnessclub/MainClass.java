
package weekendfitnessclub;


import java.util.List;
import java.util.Random;
import java.util.Scanner;


public class MainClass{
    
    
    private static final int AddCustomer = 1;
    private static final int BookLesson = 2;
    private static final int CancelOrChangeBooking = 3;
    private static final int AttendLesson = 4;
    private static final int MonthlyLessonReport = 5;
    private static final int MonthlyChampionFitnessReport = 6;
    private static final int EXIT = 7;
    
    private static final String CANCELLED = "cancelled";
    private static final String ATTENDED = "attended";
    private static final String BOOKED = "booked";
    private static final String CHANGED = "changed";
        
    private static Scanner userInput = new Scanner(System.in);

     
    /**
    * Main Method
    */
    public static void main(String[] args) {
        MainClass app = new MainClass();
        app.processFunctionality();
    }
    
    
    /**
    * Process Functionality
    */
    private void processFunctionality()
    {
        int choice = getMenuItem();
        while (choice != EXIT)
        {
            switch (choice)
            {
                case AddCustomer:
                    addCustomer();
                    break;
                case BookLesson:
                    bookLesson();
                    break;
                case CancelOrChangeBooking:
                    cancelOrChangeBooking();
                    break;
                case AttendLesson:
                    attendLesson();
                    break;
                case MonthlyLessonReport:
                    checkMonthlyLessonReport();
                    break;
                case MonthlyChampionFitnessReport:
                    checkMonthlyChampionReport();
                    break;
                default:
                    System.out.println("Error : Choice not recognised");
            }
            choice = getMenuItem();
        }
    }
    
    
    /**
    * Add New Customer
    */
    private static void addCustomer(){
        
        List<Customer> customersDetail = Customer.returnCustomers();   
        System.out.print("\nEnter Name : ");
        String name = userInput.nextLine();
        
        //Check Customer Name
        for(int i=0; i<customersDetail.size(); i++){
            String cust_name = customersDetail.get(i).getName();
            
            if(cust_name.equals(name)){
                System.out.println("Error: Customer with this name already exists. Please Enter different Name.");
                return;
            }
        }

        System.out.print("Enter Email : ");
        String email = userInput.nextLine();
        
        System.out.print("Enter Contact : ");
        String contact = userInput.nextLine();
        
        Customer obj1 = new Customer(name,email,contact);
        Customer.customers.add(obj1);
    }
    
    
    /**
    * Book New Lesson
    */
    public static void bookLesson(){
        
        // Take Choice for Timetable
        int choice = getTimetableChoice();    
        
        // Get Timetable according to weekend days
        if(choice == 1){
            getTimetableAccordingToDay();
        }
        
        // Get Timetable according to fitness type
        if(choice == 2){
            getTimetableAccordingToFitnessType();
        }  
        
        // Book a Class
        System.out.print("Do you want to book a class : ");
        String userChoice = userInput.nextLine();
        
        if(userChoice.equalsIgnoreCase("yes")){

            //Take Customer Name
            System.out.print("\nEnter Customer Name : ");
            String name = userInput.nextLine();
            
            //Check customer exists or not
            boolean returnValue = checkCustomerExistance(name);            
            if(returnValue){
                return;
            }
            
            //Take Lesson Name
            System.out.print("\nEnter Lesson Name : ");
            String lesson = userInput.nextLine();
            
            //Check whether the customer is booking same lesson twice
            boolean isTwice = isCustomerBookingSameLessonTwice(lesson,name);
            if(isTwice){
                System.out.println("Error: You can't schedule same lesson twice. To schedule, please change the lesson.");
                return;
            }
            
            //Validation for lesson, whether the lesson is booked by 5 customers or not
            int countCustomer = validateLessonBooking(lesson);
            if(countCustomer >= 5){
                System.out.println("Error: This lesson is already booked by 5 customers. To book, please change the lesson.");
                return;
            }

            //Check lesson exists in the pre-set records or not
            boolean returnValue1 = checkLessonExistance(lesson);            
            if(returnValue1){
                do {   
                    System.out.print("Error: Please Enter Valid Lesson Name : ");
                    lesson = userInput.nextLine();
                    returnValue1 = checkLessonExistance(lesson);   
                }while(returnValue1 == true);
            }
            
            String date = String.valueOf(java.time.LocalDate.now());
            
            //Get Booking Id
            int bookingId = getBookingId();
            
            //Save Booking
            Booking booking = new Booking(bookingId,name, lesson, BOOKED,date);
            Booking.bookings.add(booking);
            
            System.out.println("\nYou booked Lesson Successfully!");
            
            //Display Booking Details
            displayBookingDetails();
        }
    }
      
    
    /**
    * Cancel Or Change Booking
    */
    private static void cancelOrChangeBooking(){
        // Take Choice for cancel or change Booking
        int choice = getCancelOrChangeBookingChoice();  
        
        //Take Booking Id from user
        String bookingId = takeBookingIdFromUser();

        // Check the Booking Id exist or not
        boolean returnValue = checkBookingId(bookingId);
        if(returnValue){
            System.out.println("Error: Invalid Booking Id");
        }
        
        // Check Booking Status
        String status = checkBookingStatus(bookingId);
        if(status.equalsIgnoreCase(ATTENDED)){
            System.out.println("Error: You have already attended this lesson");
            return;
        }
                
        //If user wants to change booking
        if(choice == 1){
            changeBooking(bookingId);
            
        //If user wants to cancel booking
        }else if(choice == 2){
            cancelBooking(bookingId);
        }
    }  
    
    
    /**
    * Attend Lesson (Add Review and Rating for the lesson)
    */
    private static void attendLesson(){
       
        System.out.print("\nEnter Customer Name : ");
        String customerName = userInput.nextLine();
        
        System.out.print("\nEnter Lesson Name attended by you : ");
        String lesson = userInput.nextLine();
        
        //Check whether the customer attended this lesson or not 
        boolean check = checkLessonAttendedOrNot(customerName,lesson);
        if(check){
            System.out.println("\nError: You have already added rating for this lesson.");
            return;
        }
        
        //Check Customer has booked this lesson or not
        boolean value = checkBookingByCustomer(lesson,customerName);
        if(!value){
            System.out.println("\nnError: Maybe you didn't book this lesson or you cancelled it.");
            return;
        }
        
        System.out.print("\nEnter Review for "+lesson+" : ");
        String review = userInput.nextLine();
        
        //get rating for lesson
        int rating = getRatingForLesson();
        
        //Add Rating
        Rating rate = new Rating(customerName,lesson,review,rating);
        Rating.ratings.add(rate);
        
        //Update Booking Status to attended
        updateBookingStatusToAttended(customerName,lesson);
        
        System.out.println("\nReview and Rating for "+lesson+" is added by you");
    }
    
    
    /**
    * Check Monthly Lesson Report
    */
    private static void checkMonthlyLessonReport(){
        MonthlyLessonReport report = new MonthlyLessonReport();
        report.getReport();
    }
    
    
    /**
    * Check Monthly Champion Report
    */
    private static void checkMonthlyChampionReport(){
        MonthlyChampionReport report = new MonthlyChampionReport();
        report.getReport();  
    }
    
    
    /**
    * Display Menu
    */
    private static int getMenuItem(){        
        System.out.println("\nSelect an Option from below Menu : ");
        System.out.println(AddCustomer+". Add a New Customer");
        System.out.println(BookLesson+". Book a Lesson");
        System.out.println(CancelOrChangeBooking+". Change or Cancel a Booking");
        System.out.println(AttendLesson+". Attend a Lesson");
        System.out.println(MonthlyLessonReport+". Check Monthly Lesson Report");
        System.out.println(MonthlyChampionFitnessReport+". Check Monthly Champion Fitness Type Report");
        System.out.println(EXIT+". Exit the application");
        System.out.print("\nEnter your choice : ");

        String choice = userInput.nextLine();
        while (choice.equals("") || !isStringNumeric(choice))
        {
            System.out.println("Error : Menu selection cannot be blank and must be numeric");

            System.out.print("Enter your choice selection : ");

            choice = userInput.nextLine();
        }
        return Integer.parseInt(choice);
    }

    
    /**
    * Check whether the string is numeric
    */
    private static boolean isStringNumeric(String str)
    {
        for (int i = 0; i < str.length(); i++)
        {
            if (!Character.isDigit(str.charAt(i)))
                return false;
        }
        return true;
    }
    
    
    
    /**
    * Get user Choice for timetable
    */
    private static int getTimetableChoice(){        
        System.out.println("\n\nSelect an option to check timetable : ");
        System.out.println("1. Check By WeekDay");
        System.out.println("2. Check By Fitness Type");
        System.out.print("\nEnter your Choice : ");

        String choice = userInput.nextLine();
        while (choice.equals("") || !isStringNumeric(choice))
        {
            System.out.println("\nError : Menu selection cannot be blank and must be numeric");

            System.out.print("Enter your choice : ");

            choice = userInput.nextLine();
        }
        
        if(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 2){
            do{
                System.out.print("\nError: Enter Valid Choice : ");
                choice = userInput.nextLine();
            }while(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 2);
        }   
        
        return Integer.parseInt(choice);
    }
      
    
    /**
    * Get Timetable according to weekend day
    */
    private static void getTimetableAccordingToDay(){
        List<Timetable> timetable = Timetable.returnTimetable();
        
        System.out.print("\n\nEnter Day (Saturday/Sunday) : ");
        String weekDay = userInput.nextLine();
        if(!weekDay.equalsIgnoreCase("Saturday") && !weekDay.equalsIgnoreCase("Sunday")){
            do {
                System.out.print("Error : Enter Valid Weekend Day : ");
                Scanner sc = new Scanner(System.in);  
                weekDay = sc.nextLine();                           
            } while(!weekDay.equalsIgnoreCase("Saturday") && !weekDay.equalsIgnoreCase("Sunday"));
        }

        // Get Records

        System.out.println("\n");
        System.out.printf("%-10s %-30s %-30s %-30s %-30s %-30s %n", "S.No.","Fitness Type", "Lesson", "Price", "Day", "Date");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        int counter = 1;
        for(int i=0; i<timetable.size(); i++){
            String day = String.valueOf(timetable.get(i).getWeekDay());
            if(day.equalsIgnoreCase(weekDay)){
               System.out.printf("%-10s %-30s %-30s $%-30s %-30s %-30s %n%n", counter,timetable.get(i).lesson.getFitnessType().getFitnessType(), timetable.get(i).lesson.getLesson(),timetable.get(i).lesson.getPrice().getPrice(), timetable.get(i).getWeekDay(), timetable.get(i).getDate());
               counter = counter + 1;
            }
        }
    }
    
    
    /**
    * Get Timetable according to fitness type
    */
    private static void getTimetableAccordingToFitnessType(){
        List<Timetable> timetable = Timetable.returnTimetable();
        System.out.print("\n\nEnter Fitness Type (YOGA, ZUMBA, SPIN, BODYSCULPT) : ");
        String fitnessType = userInput.nextLine();
        if(!fitnessType.equalsIgnoreCase("YOGA") && !fitnessType.equalsIgnoreCase("ZUMBA") && !fitnessType.equalsIgnoreCase("SPIN") && !fitnessType.equalsIgnoreCase("BODYSCULPT")){
            do {
                System.out.print("Error : Enter Valid Fitness Type : ");
                Scanner sc = new Scanner(System.in);  
                fitnessType = sc.nextLine();                           
            } while(!fitnessType.equalsIgnoreCase("YOGA") && !fitnessType.equalsIgnoreCase("ZUMBA") && !fitnessType.equalsIgnoreCase("SPIN") && !fitnessType.equalsIgnoreCase("BODYSCULPT"));
        }

        // Get Records
        System.out.println("\n");
        System.out.printf("%-10s %-30s %-30s %-30s %-30s %-30s %n", "S.No.","Fitness Type", "Lesson", "Price", "Day", "Date");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        int counter = 1;
        for(int i=0; i<timetable.size(); i++){
            String type = String.valueOf(timetable.get(i).lesson.getFitnessType().getFitnessType());
            if(type.equalsIgnoreCase(fitnessType)){
                System.out.printf("%-10s %-30s %-30s $%-30s %-30s %-30s %n%n", counter, timetable.get(i).lesson.getFitnessType().getFitnessType(), timetable.get(i).lesson.getLesson(),timetable.get(i).lesson.getPrice().getPrice(), timetable.get(i).getWeekDay(), timetable.get(i).getDate());
                counter = counter + 1;
            }
           
        }
    }
    
    
    /*
    * Validate whether the customer exists or not
    */
    private static boolean checkCustomerExistance(String name){
        List<Customer> customersDetail = Customer.returnCustomers();   
            
        if(customersDetail.isEmpty()){
            System.out.println("Error: Customer does not exist. To schedule a class, please add a customer.");
            return true;
        }
                
        boolean value = customersDetail.stream().anyMatch(o -> name.equalsIgnoreCase(o.getName()));
        
        if(!value){
            System.out.println("Error: There is no such customer with this name. To schedule a class, please add a customer.");
            return true;
        }
        return false;
    }
    
    
    /*
    *  Check Entered Lesson by User exists in the records or not
    */
    private static boolean checkLessonExistance(String lesson){
        
        List<Timetable> timetable = Timetable.returnTimetable();
         
        boolean value = timetable.stream().anyMatch(o -> lesson.equalsIgnoreCase(o.lesson.getLesson()));
        
        if(!value){
            return true;
        }
        return false;
    }
    
    
    /*
    * Display Bookings Details booked by the user
    */
    private static void displayBookingDetails(){
        System.out.println("\nYour Booking Details are : \n");

        List<Booking> bookingList = Booking.returnBookings();
        List<Timetable> timetable = Timetable.returnTimetable();

        for(int i=bookingList.size(); i>0; i--){

            System.out.printf("%-20s %-30s %-30s %-30s %-30s %n", "Booking No.","Customer Name", "Lesson", "Status", "Booking Date");
            System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-20s %-30s %-30s %-30s %-30s %n", bookingList.get(bookingList.size()-1).getBookingId(),bookingList.get(bookingList.size()-1).getCustomerName(), bookingList.get(bookingList.size()-1).getLesson(), bookingList.get(bookingList.size()-1).getStatus(), bookingList.get(bookingList.size()-1).getBookingDate());

            System.out.println("\nLesson Details are : \n");
            for(int j=0; i<timetable.size(); j++){
                if(timetable.get(j).lesson.getLesson().equalsIgnoreCase(bookingList.get(bookingList.size()-1).getLesson())){
                    System.out.printf("%-30s %-30s %-30s %-30s %-30s %n", "Fitness Type", "Lesson", "Price", "Day", "Date");
                    System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("%-30s %-30s $%-30s %-30s %-30s %n%n", timetable.get(j).lesson.getFitnessType().getFitnessType(), timetable.get(j).lesson.getLesson(),timetable.get(j).lesson.getPrice().getPrice(), timetable.get(j).getWeekDay(), timetable.get(j).getDate());
                    break;
                }
            }
            break;
        }
    }
    
    
        
    /*
    * Check whether the customer is booking same lesson twice
    */
    private static boolean isCustomerBookingSameLessonTwice(String lesson, String customerName){
        List<Booking> bookingList = Booking.returnBookings();
        String status = BOOKED;
        for(int i=0; i<bookingList.size(); i++){
            boolean lessonValue = bookingList.stream().anyMatch(o -> lesson.equalsIgnoreCase(o.getLesson()));
            boolean statusValue = bookingList.stream().anyMatch(o -> status.equalsIgnoreCase(o.getStatus()));
            boolean custValue = bookingList.stream().anyMatch(o -> customerName.equalsIgnoreCase(o.getCustomerName()));
            
            if(lessonValue && custValue && statusValue){
                return true;
            }
        }
        return false;
    }
      
    
    /*
    * Check whether the lesson is booked by the 5 customers or not
    */
    private static int validateLessonBooking(String lesson){
        List<Booking> bookingList = Booking.returnBookings();
        int count = 0;
        String status = BOOKED;
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getLesson().equalsIgnoreCase(lesson) && bookingList.get(i).getStatus().equalsIgnoreCase(status)){
                count = count + 1;
            }
        }
        return count;
    }
    
    
    /*
    *  Get Booking Id
    */
    private static int getBookingId(){
        
        Random rand = new Random();
        int low = 100;
        int high = 200;
        int result = rand.nextInt(high-low) + low;
        
        boolean isExist = cancelledBookingId(result);
        
        if(!isExist){
            result = getBookingId();
        }
        return result;
    }
    
    
    /*
    * Get Cancelled Booking Id, so that it cannot be reused
    */
    private static boolean cancelledBookingId(int bookingId){
        List<Booking> bookingList = Booking.returnBookings();
        String status = "";
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getBookingId() == bookingId){
                status = bookingList.get(i).getStatus();
                boolean bookingIdValue = bookingList.stream().anyMatch(o ->String.valueOf(bookingId).equalsIgnoreCase(String.valueOf(o.getBookingId())));
                if(bookingIdValue && status.equalsIgnoreCase(CANCELLED)){
                   return false;
                }
            }
        }
        return true;
    }
    
    
    
    /*
    * Take Choice from User whether he wants to change or cancel booking
    */
    private static int getCancelOrChangeBookingChoice(){
        System.out.println("\n\nSelect an option to update Booking : ");
        System.out.println("1. Change Booking");
        System.out.println("2. Cancel Booking");
        System.out.print("\nEnter your Choice : ");

        String choice = userInput.nextLine();
        while (choice.equals("") || !isStringNumeric(choice))
        {
            System.out.println("\nError : Menu selection cannot be blank and must be numeric");

            System.out.print("Enter your choice : ");

            choice = userInput.nextLine();
        }
        
        if(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 2){
            do{
                System.out.print("\nError: Enter Valid Choice : ");
                choice = userInput.nextLine();
            }while(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 2);
        }   
        return Integer.parseInt(choice);
    }
    
    
    /*
    * Check Booking id exist or not
    */
    private static boolean checkBookingId(String bookingId){
        List<Booking> bookingList = Booking.returnBookings();
        for(int i=0; i<bookingList.size(); i++){
            boolean bookingIdValue = bookingList.stream().anyMatch(o ->String.valueOf(bookingId).equalsIgnoreCase(String.valueOf(o.getBookingId())));
            if(bookingIdValue){
                return false;
            }
        }
        return true;
    }
    
    
    /*
    * Check Booking status
    */
    private static String checkBookingStatus(String bookingId){
        List<Booking> bookingList = Booking.returnBookings();
        String status = "";
        
        for(int i=0; i<bookingList.size(); i++){
            if(String.valueOf(bookingList.get(i).getBookingId()).equalsIgnoreCase(bookingId)){
                status = bookingList.get(i).getStatus();
                return status;
            }
        }
        return status;
    }
    
    
    
    /*
    * Take Booking id from user
    */
    private static String takeBookingIdFromUser(){
        System.out.print("\nEnter your Booking Id : ");
        String bookingId = userInput.nextLine();
        
        while (bookingId.equals("") || !isStringNumeric(bookingId))
        {
            System.out.println("\nError : Booking Id cannot be blank and must be numeric");

            System.out.print("Enter your Booking Id : ");

            bookingId = userInput.nextLine();
        }
        return bookingId;
    }
    
    
    
    /*
    *  Change Booking
    */
    private static void changeBooking(String bookingId){
        
        System.out.print("\nEnter New Lesson Name : ");
        String lesson = userInput.nextLine();
        
        //Check lesson exists in the pre-set records or not
        boolean returnValue1 = checkLessonExistance(lesson);            
        if(returnValue1){
            do {   
                System.out.print("Error: Please Enter Valid Lesson Name : ");
                lesson = userInput.nextLine();
                returnValue1 = checkLessonExistance(lesson);   
            }while(returnValue1 == true);
        }
        
        List<Booking> bookingList = Booking.returnBookings();
        
        //Get Customer name
        String customerName = "";
        for(int i=0; i<bookingList.size(); i++){
            if(String.valueOf(bookingList.get(i).getBookingId()).equalsIgnoreCase(bookingId)){
                customerName = bookingList.get(i).getCustomerName();
            }
        }
        
        //Check whether the customer is booking same lesson twice
        boolean isTwice = isCustomerBookingSameLessonTwice(lesson,customerName);
        if(isTwice){
            System.out.println("Error: You can't schedule same lesson twice. To schedule, please change the lesson.");
            return;
        }

        //Validation for lesson, whether the lesson is booked by 5 customers or not
        int countCustomer = validateLessonBooking(lesson);
        if(countCustomer >= 5){
            System.out.println("Error: This lesson is already booked by 5 customers. To book, please change the lesson.");
            return;
        }
            
        //Update Bookings Details
        for(int i=0; i<bookingList.size(); i++){
            if(String.valueOf(bookingList.get(i).getBookingId()).equalsIgnoreCase(bookingId)){
                bookingList.get(i).setLesson(lesson);
                bookingList.get(i).setStatus(CHANGED);
            }
        }
        
        //Display Updated Booking Details
        displayUpdatedBookingDetails(bookingId);
    }
    
    
    /*
    * Display Updated Booking Details
    */
    private static void displayUpdatedBookingDetails(String bookingId){
        System.out.println("\nYour Updated Booking Details are : \n");
        
        List<Booking> bookingList = Booking.returnBookings();
        List<Timetable> timetable = Timetable.returnTimetable();

        for(int i=0; i<bookingList.size(); i++){

            if(String.valueOf(bookingList.get(i).getBookingId()).equalsIgnoreCase(bookingId)){
                System.out.printf("%-20s %-30s %-30s %-30s %-30s %n", "Booking No.","Customer Name", "Lesson", "Status", "Booking Date");
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("%-20s %-30s %-30s %-30s %-30s %n", bookingList.get(i).getBookingId(),bookingList.get(i).getCustomerName(), bookingList.get(i).getLesson(), bookingList.get(i).getStatus(), bookingList.get(i).getBookingDate());

                System.out.println("\nLesson Details are : \n");
                for(int j=0; i<timetable.size(); j++){
                    if(timetable.get(j).lesson.getLesson().equalsIgnoreCase(bookingList.get(i).getLesson())){
                        System.out.printf("%-30s %-30s %-30s %-30s %-30s %n", "Fitness Type", "Lesson", "Price", "Day", "Date");
                        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.printf("%-30s %-30s $%-30s %-30s %-30s %n%n", timetable.get(j).lesson.getFitnessType().getFitnessType(), timetable.get(j).lesson.getLesson(),timetable.get(j).lesson.getPrice().getPrice(), timetable.get(j).getWeekDay(), timetable.get(j).getDate());
                        break;
                    }
                }
            }
        }
    }
    
    
    /*
    *  Cancel Booking
    */
    private static void cancelBooking(String bookingId){
        // Cancel Booking
        List<Booking> bookingList = Booking.returnBookings();
        for(int i=0; i<bookingList.size(); i++){
            if(String.valueOf(bookingList.get(i).getBookingId()).equalsIgnoreCase(bookingId)){
                bookingList.get(i).setStatus(CANCELLED);
            }
        }
        
        System.out.println("\nBooking is Cancelled Successfully!");
        
        //Display Updated Booking Details
        displayUpdatedBookingDetails(bookingId);
    }
    
    
    /*
    * Check Bookings made by the customer
    */
    private static boolean checkBookingByCustomer(String lesson, String customerName){
        
        List<Booking> bookingList = Booking.returnBookings();
        String status = BOOKED;
        String changedStatus = CHANGED;
        for(int i=0; i<bookingList.size(); i++){
            boolean lessonValue = bookingList.stream().anyMatch(o ->lesson.equalsIgnoreCase(o.getLesson()));
            boolean custName = bookingList.stream().anyMatch(o ->customerName.equalsIgnoreCase(o.getCustomerName()));
            boolean bookingStatus = bookingList.stream().anyMatch(o ->status.equalsIgnoreCase(o.getStatus()));
            boolean bookingChangedStatus = bookingList.stream().anyMatch(o ->changedStatus.equalsIgnoreCase(o.getStatus()));

            if(lessonValue && custName && bookingStatus || bookingChangedStatus){
                return true;
            }
        }
        return false;
    }
    
    
    
    /*
    * Get Rating for Lesson
    */
    private static int getRatingForLesson(){
        System.out.println("\nSelect Rating : ");
        System.out.println("1. Very Dissatisfied");
        System.out.println("2. Dissatisfied");
        System.out.println("3. OK");
        System.out.println("4. Satisfied");
        System.out.println("5. Very Satisfied");
        
        System.out.print("\nEnter your Choice : ");
        String choice = userInput.nextLine();
        
        while (choice.equals("") || !isStringNumeric(choice))
        {
            System.out.println("\nError : Menu selection cannot be blank and must be numeric");

            System.out.print("Enter your choice : ");

            choice = userInput.nextLine();
        }
        
        if(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 5){
            do{
                System.out.print("\nError: Enter Valid Choice : ");
                choice = userInput.nextLine();
            }while(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 2);
        }   
        return Integer.parseInt(choice);
    }
    
    
    
    /*
    * Update Booking  status to attended
    */
    private static void updateBookingStatusToAttended(String customerName, String lesson){
        List<Booking> bookingList = Booking.returnBookings();
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getCustomerName().equalsIgnoreCase(customerName) && bookingList.get(i).getLesson().equalsIgnoreCase(lesson)){
                bookingList.get(i).setStatus(ATTENDED);
            }
        }
    }
        
    
    /*
    *  Check customer attended lesson or not
    */
    private static boolean checkLessonAttendedOrNot(String customerName, String lesson){
        List<Rating> ratingList = Rating.returnRatings();
        for(int i=0; i<ratingList.size(); i++){
            if(ratingList.get(i).getCustomerName().equalsIgnoreCase(customerName) && ratingList.get(i).getLesson().equalsIgnoreCase(lesson)){
                return true;
            }
        }
        return false;
    }

}
