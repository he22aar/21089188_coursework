
package weekendfitnessclub;

import java.util.List;

public class MonthlyChampionReport extends Report{

    @Override
    void getReport() {
        List<Booking> bookingList = Booking.returnBookings();
        List<Timetable> timetable = Timetable.returnTimetable();
        
        double totalIncome = 0.0;
        String lesson = "";
        System.out.println();
        System.out.printf("%-10s %-50s %-50s %n", "S.No.","Lesson", "Total Income Generated");
        System.out.println("------------------------------------------------------------------------------------------------");
        for(int i=0; i<timetable.size(); i++){
            for(int j=0; j<bookingList.size(); j++){

                if(timetable.get(i).lesson.getLesson().equalsIgnoreCase(bookingList.get(j).getLesson())){
                    totalIncome = totalIncome +  timetable.get(i).lesson.getPrice().getPrice();
                    lesson = bookingList.get(j).getLesson();
                }               
            }
            if(!timetable.get(i).lesson.getLesson().equalsIgnoreCase(lesson)){
                totalIncome = 0;
            }
            System.out.printf("%-10s %-50s $%-50s %n%n", (i+1),timetable.get(i).lesson.getLesson(),totalIncome);
        }
    }
    
}
