
package weekendfitnessclub;



public class FitnessLesson {
 
    private FitnessType fitnessType;
    private FitnessType price;
    private String lesson;

    public FitnessLesson() {
    }

    public FitnessLesson(FitnessType fitnessType, String lesson, FitnessType price) {
        this.fitnessType = fitnessType;
        this.lesson = lesson;
        this.price = price;
    }
    
    public String getLesson() {
        return lesson;
    }

    public FitnessType getFitnessType() {
        return fitnessType;
    }
    
    public FitnessType getPrice() {
        return price;
    }
}
