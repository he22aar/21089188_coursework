
package weekendfitnessclub;

import java.util.ArrayList;
import java.util.List;


public class Timetable {
    
    private int timetableId;
    public FitnessLesson lesson;
    private String weekDay;
    private String date;

    public static List<Timetable> timetable = new ArrayList<>();
    
    public Timetable() {
    }

    public Timetable(int timetableId, FitnessLesson lesson, String weekDay, String date) {
        this.timetableId = timetableId;
        this.lesson = lesson;
        this.weekDay = weekDay;
        this.date = date;
    }

    public int getTimetableId() {
        return timetableId;
    }

    public FitnessLesson getLesson() {
        return lesson;
    }

    public String getWeekDay() {
        return weekDay;
    }

    public String getDate() {
        return date;
    }
    
    
    // ArrayList for all lessons
    public static ArrayList returnTimetable() {
        Timetable obj1 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 1",new FitnessType("Yoga",75)),"Saturday","11 March,2023");
        Timetable obj2 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 1",new FitnessType("ZUMBA",62)),"Sunday","12 March,2023");
        Timetable obj3 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 1",new FitnessType("SPIN",54)),"Saturday","11 March,2023");
        Timetable obj4 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 1",new FitnessType("BODYSCULPT",59)),"Sunday","12 March,2023");
        
        
        Timetable obj5 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 2",new FitnessType("Yoga",75)),"Sunday","19 March,2023");
        Timetable obj6 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 2",new FitnessType("ZUMBA",62)),"Saturday","18 March,2023");
        Timetable obj7 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 2",new FitnessType("SPIN",54)),"Sunday","19 March,2023");
        Timetable obj8 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 2",new FitnessType("BODYSCULPT",59)),"Saturday","18 March,2023");
        
        
        Timetable obj9 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 3",new FitnessType("Yoga",75)),"Saturday","25 March,2023");
        Timetable obj10 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 3",new FitnessType("ZUMBA",62)),"Sunday","26 March,2023");
        Timetable obj11 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 3",new FitnessType("SPIN",54)),"Saturday","25 March,2023");
        Timetable obj12 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 3",new FitnessType("BODYSCULPT",59)),"Sunday","26 March,2023");
        
        Timetable obj13 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 4",new FitnessType("Yoga",75)),"Sunday","2 April,2023");
        Timetable obj14 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 4",new FitnessType("ZUMBA",62)),"Saturday","1 April,2023");
        Timetable obj15 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 4",new FitnessType("SPIN",54)),"Sunday","2 April,2023");
        Timetable obj16 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 4",new FitnessType("BODYSCULPT",59)),"Saturday","1 April,2023");
        
        
        Timetable obj17 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 5",new FitnessType("Yoga",75)),"Saturday","8 April,2023");
        Timetable obj18 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 5",new FitnessType("ZUMBA",62)),"Sunday","9 April,2023");
        Timetable obj19 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 5",new FitnessType("SPIN",54)),"Saturday","8 April,2023");
        Timetable obj20 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 5",new FitnessType("BODYSCULPT",59)),"Sunday","9 April,2023");
        
        
        Timetable obj21 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 6",new FitnessType("Yoga",75)),"Sunday","16 April,2023");
        Timetable obj22 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 6",new FitnessType("ZUMBA",62)),"Saturday","15 April,2023");
        Timetable obj23 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 6",new FitnessType("SPIN",54)),"Sunday","16 April,2023");
        Timetable obj24 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 6",new FitnessType("BODYSCULPT",59)),"Saturday","15 April,2023");
        
        
        Timetable obj25 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 7",new FitnessType("Yoga",75)),"Saturday","22 April,2023");
        Timetable obj26 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 7",new FitnessType("ZUMBA",62)),"Sunday","23 April,2023");
        Timetable obj27 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 7",new FitnessType("SPIN",54)),"Saturday","22 April,2023");
        Timetable obj28 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 7",new FitnessType("BODYSCULPT",59)),"Sunday","23 April,2023");
        
        
        Timetable obj29 = new Timetable(1,new FitnessLesson(new FitnessType("Yoga",75),"Yoga Lesson 8",new FitnessType("Yoga",75)),"Sunday","30 April,2023");
        Timetable obj30 = new Timetable(2,new FitnessLesson(new FitnessType("ZUMBA",62),"Zumba Lesson 8",new FitnessType("ZUMBA",62)),"Saturday","29 April,2023");
        Timetable obj31 = new Timetable(3,new FitnessLesson(new FitnessType("SPIN",54),"Spin Lesson 8",new FitnessType("SPIN",54)),"Sunday","30 April,2023");
        Timetable obj32 = new Timetable(4,new FitnessLesson(new FitnessType("BODYSCULPT",59),"Bodysculpt Lesson 8",new FitnessType("BODYSCULPT",59)),"Saturday","29 April,2023");
               
        
   
        ArrayList <Timetable> timetable = new ArrayList<>();
        timetable.add(obj1);
        timetable.add(obj2);
        timetable.add(obj3);
        timetable.add(obj4);
        timetable.add(obj5);
        timetable.add(obj6);
        timetable.add(obj7);
        timetable.add(obj8);
        timetable.add(obj9);
        timetable.add(obj10);
        timetable.add(obj11);
        timetable.add(obj12);
        timetable.add(obj13);
        timetable.add(obj14);
        timetable.add(obj15);
        timetable.add(obj16);
        timetable.add(obj17);
        timetable.add(obj18);
        timetable.add(obj19);
        timetable.add(obj20);
        timetable.add(obj21);
        timetable.add(obj22);
        timetable.add(obj23);
        timetable.add(obj24);
        timetable.add(obj25);
        timetable.add(obj26);
        timetable.add(obj27);
        timetable.add(obj28);
        timetable.add(obj29);
        timetable.add(obj30);
        timetable.add(obj31);
        timetable.add(obj32);
        return timetable;
    }
    
   
}
