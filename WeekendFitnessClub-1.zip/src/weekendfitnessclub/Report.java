
package weekendfitnessclub;

abstract class Report {
    
    abstract void getReport();  
}
