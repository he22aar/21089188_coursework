
package weekendfitnessclub;

public class FitnessType {
    
    private String fitnessType;
    private double price;

    public FitnessType(String fitnessType, double price) {
        this.fitnessType = fitnessType;
        this.price = price;
    }

    public String getFitnessType() {
        return fitnessType;
    }

    public double getPrice() {
        return price;
    }
   
    
}
