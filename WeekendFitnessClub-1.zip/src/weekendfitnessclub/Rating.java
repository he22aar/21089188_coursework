
package weekendfitnessclub;

import java.util.ArrayList;
import java.util.List;


public class Rating {
   
    private String customerName;
    private String lesson;
    private String review;
    private int rating;
    
    public static List<Rating> ratings = new ArrayList<>();

    public Rating(String customerName, String lesson, String review, int rating) {
        this.customerName = customerName;
        this.lesson = lesson;
        this.review = review;
        this.rating = rating;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getLesson() {
        return lesson;
    }

    public String getReview() {
        return review;
    }

    public int getRating() {
        return rating;
    }
    
    public static  List<Rating> returnRatings(){
        return ratings;
    }
    
}
