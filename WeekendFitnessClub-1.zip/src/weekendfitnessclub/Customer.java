
package weekendfitnessclub;

import java.util.ArrayList;
import java.util.List;


public class Customer {
    
    private String name;
    private String email;
    private String contact;

    public static List<Customer> customers = new ArrayList<>();
     
    public Customer() {
    }

    public Customer(String name, String email, String contact) {
        this.name = name;
        this.email = email;
        this.contact = contact;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getContact() {
        return contact;
    }

    public static  List<Customer> returnCustomers(){
        return customers;
    }
}
