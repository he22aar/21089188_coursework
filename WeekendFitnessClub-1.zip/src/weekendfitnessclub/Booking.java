
package weekendfitnessclub;

import java.util.ArrayList;
import java.util.List;


public class Booking {
   
    private int bookingId;
    private String customerName;
    private String lesson;
    private String status;
    private String bookingDate;
    
    public static List<Booking> bookings = new ArrayList<>();
    
    public Booking() {
    }

    public Booking(int bookingId, String customerName, String lesson, String status, String bookingDate) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.lesson = lesson;
        this.status = status;
        this.bookingDate = bookingDate;
    }
    
    public int getBookingId() {
        return bookingId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getLesson() {
        return lesson;
    }

    public String getStatus() {
        return status;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setLesson(String lesson) {
        this.lesson = lesson;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    public static  List<Booking> returnBookings(){
        return bookings;
    }

}
