
package weekendfitnessclub;

import java.util.List;


public class MonthlyLessonReport extends Report {   
    @Override
    void getReport() {
        List<Booking> bookingList = Booking.returnBookings();
        List<Timetable> timetable = Timetable.returnTimetable();
        List<Rating> rating = Rating.returnRatings();
        int noOfCust = 0;
        int noOfRatings = 0;
        int totalRating = 0;
        
        String lesson = "";
        String lesson1 = "";
        System.out.println();
        System.out.printf("%-10s %-50s %-50s %-50s %n", "S.No.","Lesson", "Number Of Customers", "Average Ratings");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
        for(int i=0; i<timetable.size(); i++){
            
            //Get Number of customer who booked a lesson
            for(int j=0; j<bookingList.size(); j++){
                
                if(timetable.get(i).lesson.getLesson().equalsIgnoreCase(bookingList.get(j).getLesson())){
                    noOfCust = noOfCust + 1;
                    lesson = bookingList.get(j).getLesson();
                }               
            }
            
            //Average Rating
            for(int k=0; k<rating.size(); k++){
                    
                if(timetable.get(i).lesson.getLesson().equalsIgnoreCase(rating.get(k).getLesson())){
                    noOfRatings = noOfRatings + 1;
                    totalRating = totalRating + rating.get(k).getRating();
                    lesson1 = rating.get(k).getLesson();
                }

            }
            
            if(!timetable.get(i).lesson.getLesson().equalsIgnoreCase(lesson)){
                noOfCust = 0;
            }
            
            if(!timetable.get(i).lesson.getLesson().equalsIgnoreCase(lesson1)){
                noOfRatings = 0;
                totalRating = 0;
            }
            double customerRating = 0.0;
            if(noOfRatings != 0){
                customerRating = totalRating/noOfRatings;
            }else{
                customerRating = 0;
            }
            
            System.out.printf("%-10s %-50s %-50s %-50s %n%n", (i+1),timetable.get(i).lesson.getLesson(),noOfCust, customerRating);
        }
    }
}
