

import java.util.List;
import java.util.Random;
import org.junit.Test;
import static org.junit.Assert.*;
import weekendfitnessclub.Booking;
import weekendfitnessclub.Timetable;


public class MainTestClass {
    

    @Test
    public void checkNoOfLessons() {
       System.out.println("\n\nTest Case : To check whether there are 32 lessons in the timetable");
       
       List<Timetable> timetable = Timetable.returnTimetable();
       
       if(timetable.size() == 32){
            System.out.println("Result : Test Passed");
            assert true;
            return;
       }else{
           fail("Test Failed");
       }
    }
    
    
    @Test
    public void searchTimetableByFitnessType() {
       System.out.println("\n\nTest Case : To search timetable by Fitness Type");
       
       String fitnessType = "Yoga";
       
       List<Timetable> timetable = Timetable.returnTimetable();
       System.out.println();
       System.out.printf("%-30s %-30s %-30s %-30s %-30s %n", "Fitness Type", "Lesson", "Price", "Day", "Date");
       System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");

       for(int i=0; i<timetable.size(); i++){
           if(timetable.get(i).lesson.getFitnessType().getFitnessType().equalsIgnoreCase(fitnessType)){
                System.out.printf("%-30s %-30s $%-30s %-30s %-30s %n%n", timetable.get(i).lesson.getFitnessType().getFitnessType(), 
                        timetable.get(i).lesson.getLesson(),timetable.get(i).lesson.getPrice().getPrice(), timetable.get(i).getWeekDay(), 
                        timetable.get(i).getDate());
           }
       }
       if(!timetable.isEmpty()){
           System.out.println("Result: Test Passed");
           assert true;
           return;
       }else{
           fail("Test Failed");
       }
    }
    
    
    
    @Test
    public void searchTimetableOfSunday() {
       System.out.println("\n\nTest Case : To search timetable of Sunday");
       
       String day = "sunday";
       
       List<Timetable> timetable = Timetable.returnTimetable();
       System.out.println();
       System.out.printf("%-30s %-30s %-30s %-30s %-30s %n", "Fitness Type", "Lesson", "Price", "Day", "Date");
       System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");

       for(int i=0; i<timetable.size(); i++){
           if(timetable.get(i).getWeekDay().equalsIgnoreCase(day)){
                System.out.printf("%-30s %-30s $%-30s %-30s %-30s %n%n", timetable.get(i).lesson.getFitnessType().getFitnessType(), 
                        timetable.get(i).lesson.getLesson(),timetable.get(i).lesson.getPrice().getPrice(), timetable.get(i).getWeekDay(), 
                        timetable.get(i).getDate());
           }
       }
       if(!timetable.isEmpty()){
           System.out.println("Result: Test Passed");
           assert true;
           return;
       }else{
           fail("Test Failed");
       }
    }
    
    
    
    
    @Test
    public void searchTimetableOfSaturday() {
       System.out.println("\n\nTest Case : To search timetable of Saturday");
       
       String day = "saturday";
       
       List<Timetable> timetable = Timetable.returnTimetable();
       System.out.println();
       System.out.printf("%-30s %-30s %-30s %-30s %-30s %n", "Fitness Type", "Lesson", "Price", "Day", "Date");
       System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");

       for(int i=0; i<timetable.size(); i++){
           if(timetable.get(i).getWeekDay().equalsIgnoreCase(day)){
                System.out.printf("%-30s %-30s $%-30s %-30s %-30s %n%n", timetable.get(i).lesson.getFitnessType().getFitnessType(), 
                        timetable.get(i).lesson.getLesson(),timetable.get(i).lesson.getPrice().getPrice(), timetable.get(i).getWeekDay(), 
                        timetable.get(i).getDate());
           }
       }
       if(!timetable.isEmpty()){
           System.out.println("Result: Test Passed");
           assert true;
           return;
       }else{
           fail("Test Failed");
       }
    }
    
    
    @Test
    public void bookClass() {
        System.out.println("\n\nTest Case : To book a lesson");
        String customerName = "John";
        String lesson  = "yoga lesson 3";
        Random rand = new Random();
        int low = 100;
        int high = 200;
        int bookingId = rand.nextInt(high-low) + low;
        
        String date = String.valueOf(java.time.LocalDate.now());

        Booking booking = new Booking(bookingId,customerName, lesson, "booked",date);
        Booking.bookings.add(booking);
        
        displayBookingDetails();
        System.out.println("Result: Test Passed");
    }
    
    
    private static void displayBookingDetails(){
        System.out.println("\nYour Booking Details are : \n");

        List<Booking> bookingList = Booking.returnBookings();
        List<Timetable> timetable = Timetable.returnTimetable();

        for(int i=bookingList.size(); i>0; i--){

            System.out.printf("%-20s %-30s %-30s %-30s %-30s %n", "Booking No.","Customer Name", "Lesson", "Status", "Booking Date");
            System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-20s %-30s %-30s %-30s %-30s %n", bookingList.get(bookingList.size()-1).getBookingId(),
                    bookingList.get(bookingList.size()-1).getCustomerName(), bookingList.get(bookingList.size()-1).getLesson(), 
                    bookingList.get(bookingList.size()-1).getStatus(), bookingList.get(bookingList.size()-1).getBookingDate());

            System.out.println("\nLesson Details are : \n");
            for(int j=0; i<timetable.size(); j++){
                if(timetable.get(j).lesson.getLesson().equalsIgnoreCase(bookingList.get(bookingList.size()-1).getLesson())){
                    System.out.printf("%-30s %-30s %-30s %-30s %-30s %n", "Fitness Type", "Lesson", "Price", "Day", "Date");
                    System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("%-30s %-30s $%-30s %-30s %-30s %n%n", timetable.get(j).lesson.getFitnessType().getFitnessType(), 
                            timetable.get(j).lesson.getLesson(),timetable.get(j).lesson.getPrice().getPrice(), timetable.get(j).getWeekDay(), 
                            timetable.get(j).getDate());
                    break;
                }
            }
            break;
        }
    }
    
    
    @Test
    public void checkLessonCapacity(){
        System.out.println("\n\nTest Case : To check lesson capacity before booking a lesson");
        String lesson = "yoga lesson 3";
        addFiveBookingForLesson(lesson);
        
        int capacity = 5;
        
        List<Booking> bookingList = Booking.returnBookings();
        int count = 0;
        String status = "booked";
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getLesson().equalsIgnoreCase(lesson) && bookingList.get(i).getStatus().equalsIgnoreCase(status)){
                count = count + 1;
            }
        }
        
        if(count >= capacity){
            System.out.println("\nError : "+lesson+" is booked by 5 customers. Please change the lesson to book.");
            System.out.println("Result: Test Passed");
            assert true;
            return;
        }else{
            fail("Test Failed");
        }
    }
    
    
    private static void addFiveBookingForLesson(String lesson){
        List<Booking> bookingList = Booking.returnBookings();
        String date = String.valueOf(java.time.LocalDate.now());
        Booking booking1 = new Booking(101,"Allen", lesson, "booked",date);
        Booking booking2 = new Booking(102,"Jack", lesson, "booked",date);
        Booking booking3 = new Booking(103,"Robin", lesson, "booked",date);
        Booking booking4 = new Booking(104,"Robert", lesson, "booked",date);
        Booking booking5 = new Booking(104,"Lewis", lesson, "booked",date);

        Booking.bookings.add(booking1);
        Booking.bookings.add(booking2);
        Booking.bookings.add(booking3);
        Booking.bookings.add(booking4);
        Booking.bookings.add(booking5);
    }
    
    
    
    @Test
    public void validateCustomerToBookLessonTwice(){
        System.out.println("\n\nTest Case : To prove that, a customer cannot book the same lesson twice.");
        String lesson = "yoga lesson 3";
        String customerName = "Allen";

        addFiveBookingForLesson(lesson);
                
        List<Booking> bookingList = Booking.returnBookings();
        String status = "booked";
        boolean value = false;
        
        for(int i=0; i<bookingList.size(); i++){
            boolean lessonValue = bookingList.stream().anyMatch(o -> lesson.equalsIgnoreCase(o.getLesson()));
            boolean statusValue = bookingList.stream().anyMatch(o -> status.equalsIgnoreCase(o.getStatus()));
            boolean custValue = bookingList.stream().anyMatch(o -> customerName.equalsIgnoreCase(o.getCustomerName()));
            
            if(lessonValue && custValue && statusValue){
                value = true;
            }
        }
        
        if(value){
            System.out.println("\nError: '"+customerName+"' cannot book the same lesson twice");
            System.out.println("Result: Test Passed");
            assert true;
            return;
        }else{
            fail("Test Failed");
        }
    }
      
}
